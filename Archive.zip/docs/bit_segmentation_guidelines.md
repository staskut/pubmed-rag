# Bit-boundary annotation guidelines

Policy version: `bit_boundary_v1`.

## Objective

Create a human-reviewed reference set for evaluating automatic segmentation of
stand-up transcripts. The annotation target is the boundary between contiguous
bits, not a topic label, joke-quality score, or transcript correction.

A **bit** is a contiguous run of performance speech centered on one primary
comedic premise. It can contain setup, punchlines, tags, act-outs, examples,
brief audience interaction, and short digressions that still serve that
premise.

Boundaries are constrained to the start of a canonical caption segment. This
keeps every label traceable to an existing timestamp and avoids inventing
character offsets that the source captions cannot support.

## Annotation unit

The sampler creates two excerpts from each reviewed performance. Each excerpt
contains:

- a central `SCORED` region of about 220 words;
- approximately 60 words of `CONTEXT` on each side;
- the original segment indexes and timestamps;
- no model-generated boundary suggestions.

Annotate every row in the excerpt so its context is internally coherent.
Evaluation metrics count only boundaries whose reference position lies in the
`SCORED` region.

## Boundary decision

For `boundary_before`, choose:

- `YES`: the current kept segment begins a new primary premise;
- `NO`: the current segment continues the same bit;
- `UNSURE`: two or more boundary choices remain genuinely defensible after
  reading the complete excerpt.

The first kept segment in an excerpt is not automatically a semantic boundary.
Mark it `YES` only when the excerpt contains evidence that a bit begins there.
A boundary created solely by the sampler's truncation must not be scored as a
real bit boundary.

### Strong positive signals

Use `YES` when the semantic evidence supports a new premise, especially when
multiple signals agree:

1. the subject or comic proposition changes;
2. the comedian explicitly closes or abandons the previous premise;
3. a transition such as “anyway,” “moving on,” or a new question introduces a
   different premise;
4. a sustained crowd-work exchange starts on a different subject;
5. a pause or delivery reset accompanies a semantic change.

A pause alone is not sufficient. Caption punctuation alone is not sufficient.
Fixed word length is never a reason for a human boundary.

### Keep inside the same bit

Use `NO` for:

- punchlines, tags, lists, examples, or act-outs serving the same premise;
- escalating variations on the same setup;
- brief audience reactions or one-line interactions;
- a local clarification or digression that returns immediately;
- a shift from setup to payoff;
- laughter, applause, or transcription cues embedded within an ongoing bit.

### Callbacks

Bits must remain contiguous. A callback to earlier material stays in the
currently active bit; do not create a discontiguous bit that reaches backward.
Use `callback` as the boundary reason only when a new, sustained callback
sequence begins. Note the earlier reference in `annotator_notes` when useful.

### Crowd work

Brief responses remain with the surrounding bit. Start a new bit only when the
interaction becomes sustained and develops its own premise. Use
`crowd_work_shift` as the reason.

## Inclusion decision

For `segment_action`, choose:

- `KEEP`: analyzable routine content;
- `EXCLUDE`: audio-only cues, venue/host introductions, credits, housekeeping,
  unrelated promotion, or other non-routine material;
- `UNSURE`: inclusion is ambiguous.

Do not exclude a segment merely because it contains offensive language, an
imperfect caption, audience laughter, or a weak joke. These are properties of
the source performance, not annotation failures.

A `YES` boundary cannot be placed on an `EXCLUDE` row. The next kept row may be
marked `YES` if it begins a real bit.

## Boundary reasons

Every `YES` must have one reason:

| Code | Meaning |
|---|---|
| `new_premise` | A new core subject or comic proposition begins |
| `explicit_transition` | The performer explicitly moves on |
| `pause_or_delivery_shift` | A strong delivery reset supports a semantic change |
| `crowd_work_shift` | A sustained, distinct audience interaction begins |
| `intro_outro` | Routine material begins or ends around non-routine speech |
| `callback` | A new contiguous callback sequence begins |
| `other` | None fit; explain in notes |

## Confidence and adjudication

Confidence is an ordinal judgment:

- `1`: very uncertain;
- `2`: low confidence;
- `3`: moderate confidence;
- `4`: high confidence;
- `5`: very confident.

Use `UNSURE` rather than forcing a label. Samples containing unresolved
uncertainty should be marked `needs_adjudication`. For a stronger experiment,
two annotators should label independently before discussing disagreements.

The adjudicated label is the evaluation reference. Raw annotator decisions
should be retained so inter-annotator agreement can be reported.

## Quality checks

A sample is ready for evaluation only when:

- every segment has a boundary and inclusion decision;
- every `YES` has a reason and confidence;
- no `YES` occurs on an excluded row;
- ambiguous decisions have notes;
- the sample status is `reviewed` or `adjudicated`;
- the local workbook and exported labels remain outside version control.

Transcript excerpts may include mature or offensive language because they are
unaltered research observations. Their presence is not an endorsement.
