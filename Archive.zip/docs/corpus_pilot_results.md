# English Creative Commons corpus pilot

Review and ingestion date: 25 July 2026.

## Outcome

The official YouTube discovery search returned 439 unique metadata candidates.
Of these, 438 passed a second check for:

- `status.license=creativeCommon`;
- `contentDetails.caption=true`;
- public visibility;
- external embedding.

A conservative metadata heuristic produced 15 likely stand-up candidates. The
initial manual review accepted eight for local research ingestion and rejected
seven as archival material, podcasts, likely reuploads, or
unrelated/keyword-stuffed uploads.

A subsequent review of five user-selected videos accepted two Comedy Store
recordings and rejected three apparent reuploads of commercial material. The
review log now contains 20 decisions: ten accepted and ten rejected. The
complete decisions and reasons are recorded in
`config/reviews/youtube_cc_review_decisions.json`.

## Accepted corpus

The accepted source manifest is
`config/sources/youtube_cc_reviewed.json`. The selection contains:

- one special published by its producer;
- two performer-channel full sets/specials;
- five venue-published single-comedian sets;
- one university-museum event recording;
- one performer-channel self-released special.

Every accepted video's official API metadata reported a Creative Commons
license. The uploader was manually assessed as a plausible performer, producer,
venue, or event host. This is a metadata-level research decision, not legal
advice or proof of chain of title. Public transcript display remains disabled.

## Transcript acquisition result

All ten accepted candidates were successfully retrieved through the
version-pinned `youtube-transcript-api` adapter:

| Metric | Result |
|---|---:|
| Performances | 10 |
| Manually created English caption tracks | 10 |
| Generated caption tracks | 0 |
| Caption segments | 5,386 |
| Words | 37,924 |
| Timestamped duration | 3.93 hours |
| Provisional fixed-word windows | 311 |
| Empty normalized segments | 0 |
| Out-of-order timestamps | 0 |
| Consecutive repeated caption texts | 19 (0.35% of segments) |
| Smallest transcript | 973 words |
| Median transcript | 2,204 words |
| Largest transcript | 10,688 words |

All raw and normalized transcript text is stored only in gitignored local data
directories. A second ingestion run used the immutable raw cache for all ten
videos and made no transcript request.

The 19 consecutive repeated caption texts are retained for now because repeated
phrases can be intentional comedic delivery. Their small rate does not block the
pilot, but normalization experiments should measure the effect of removing them
rather than deleting them blindly.

The provisional windows are not production bits. One long special still
contains a short window caused by a performance pause; semantic segmentation is
deferred to the planned LLM experiment.

## Warehouse result

The reviewed corpus was loaded through dlt into the gitignored local DuckDB
database at `data/warehouse/comedy.duckdb`. It contains ten performances, 5,386
segments, 311 provisional windows, ten QA records, and an append-only ingestion
run log.

A second warehouse load left every corpus-table count unchanged and added only
one ingestion-run audit record. This verifies idempotent merge behavior for the
current manifest.

## Diversity finding

The pilot proves that a meaningful amount of high-quality English text can be
acquired from a small reviewed CC candidate set. It does not prove geographic
diversity. The successful candidates were found primarily through US-oriented
searches, and search region is not evidence of a comedian's national or
cultural affiliation.

No country label should be assigned until it is supported by a reliable source.
The current corpus therefore supports ingestion, retrieval, and segmentation
experiments, but not the Cultural Horizon Scanner's country comparisons.

The next corpus-acquisition milestone is to add independently verified UK,
Canadian, and Australian performers or revise the product's geographic scope.
