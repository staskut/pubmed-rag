# dlt and DuckDB corpus warehouse

The next ingestion stage loads reviewed, normalized transcript data into a
queryable local warehouse using dlt and DuckDB.

The pipeline follows the course's automated-ingestion requirement while keeping
source acquisition separate from database loading:

```text
reviewed source manifest
  -> cached canonical JSONL and QA
  -> dlt resources with merge keys
  -> DuckDB corpus schema
```

## Run

```bash
.venv/bin/python -m pip install -e '.[dev]'
.venv/bin/load-corpus
```

The default database is `data/warehouse/comedy.duckdb`. Transcript text and the
database are gitignored.

## Tables

| Table | Purpose | Load behavior |
|---|---|---|
| `corpus.performances` | Source, performer, rights and attribution metadata | Merge by `source_id` |
| `corpus.transcript_segments` | Canonical timestamped caption segments | Merge by source and segment index |
| `corpus.bit_candidates` | Temporary fixed-word review windows | Merge by `bit_id` |
| `corpus.transcript_quality` | Per-video QA metrics and checks | Merge by `source_id` |
| `corpus.ingestion_runs` | Manifest hash, pipeline version and run counts | Append |

Running the pipeline again updates corpus records without duplicating them.
Every execution appends one auditable ingestion-run record. The temporary
`bit_candidates` table will later be replaced or supplemented by versioned
LLM-segmented bits.

## Pilot validation

The first real load on 25 July 2026 produced:

| Table | Rows |
|---|---:|
| `corpus.performances` | 10 |
| `corpus.transcript_segments` | 5,386 |
| `corpus.bit_candidates` | 311 |
| `corpus.transcript_quality` | 10 |
| `corpus.ingestion_runs` | 1 |

After a second identical load, the four corpus-table counts were unchanged and
`corpus.ingestion_runs` increased to two.
