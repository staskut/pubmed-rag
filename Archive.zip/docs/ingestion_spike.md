# YouTube ingestion spike

## Goal

Prove the riskiest part of the product with one English stand-up video before
introducing dlt, Kestra, a database, or LLM-based bit segmentation.

The spike establishes this contract:

```text
reviewed source manifest
  -> transcript adapter
  -> immutable raw cache
  -> canonical timestamped segments
  -> provisional bit windows
  -> machine-readable QA report
```

The fixed-word windows are only review units. They are explicitly marked
`fixed_word_window_v0` and must not be presented as semantically complete bits.

## Safety and rights

The checked-in spike manifest uses `test_only_unverified`. The CLI refuses to
ingest that source unless `--allow-test-only` is supplied. Fetched transcript
text is stored under the gitignored `data/raw` and `data/processed` directories.
It must not be committed, redistributed, or shown in the public application.

For a distributable corpus, replace the test source with a video marked
`approved_cc_by` or `permission_on_file`, and attach the corresponding immutable
license evidence or permission record.

## Run

From the repository root:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -e '.[dev]'
.venv/bin/ingest-youtube --allow-test-only
.venv/bin/pytest
```

The first run fetches the transcript. Later runs use the immutable local cache;
pass `--refresh` only when intentionally testing reacquisition.

## Outputs

For each video ID:

- `data/raw/youtube/<video-id>.json`: original adapter response plus source
  manifest snapshot, retrieval timestamp, adapter version, and content hash.
- `data/processed/youtube/<video-id>.segments.jsonl`: normalized timestamped
  caption segments.
- `data/processed/youtube/<video-id>.bit-candidates.jsonl`: deterministic,
  reviewable windows that preserve source timestamps.
- `data/processed/youtube/<video-id>.qa.json`: counts and validation results
  without transcript text.

## Exit criteria

The spike succeeds when:

- an English caption track can be fetched locally;
- raw acquisition is cached and content-addressed;
- a second run is a cache hit;
- normalized timestamps remain monotonic;
- at least 100 words are available;
- tests can run without making a YouTube request.

After those checks pass, the next ingestion milestone is to wrap the normalized
records in dlt and orchestrate the job with Kestra. Semantic bit segmentation
and its human-labeled evaluation set come after the ingestion boundary is
stable.

## First local result (25 July 2026)

The test-only manifest source ingested successfully:

- manually created `en-US` caption track;
- 298 raw and canonical segments;
- 2,155 words over 831.831 seconds;
- 18 provisional review windows after merging a tiny punchline fragment;
- monotonic timestamps, no empty normalized segments, and one repeated segment
  text;
- raw cache size about 40 KB and normalized segment data about 104 KB;
- the second run completed without a network request (`cache_status=hit`);
- four offline tests pass against a fake adapter.

The first windowing pass exposed a useful failure mode: an audience pause split
a ten-word punchline from its setup. The baseline now coalesces tiny trailing
fragments when the merged window remains below 180 words. This improves review
units but does not solve semantic bit segmentation; that remains an evaluated
LLM/NLP stage.
