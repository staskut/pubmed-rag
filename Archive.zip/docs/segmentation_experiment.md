# Bit-segmentation experiment

## Goal

Select a reproducible method that converts canonical caption segments into
contiguous, searchable comedy bits. The choice must be supported by a
human-reviewed boundary set rather than visual inspection alone.

## Gold-set construction

Generate the local template with:

```bash
.venv/bin/sample-segmentation-gold
```

Defaults:

| Parameter | Value |
|---|---:|
| Performances | 10 |
| Excerpts per performance | 2 |
| Total excerpts | 20 |
| Scored words per excerpt | About 220 |
| Context words per side | About 60 |
| Deterministic seed | 20260725 |

The current run produced 20 excerpts, 750 caption rows, 7,255 visible words,
and 4,648 scored words. Context is clipped between nearby excerpts so no source
caption is annotated twice.

Generated transcript-bearing files are written to
`data/annotations/segmentation_gold_v1/` and are gitignored. The tracked
machine-readable contract is
`config/schemas/segmentation_gold_set.schema.json`. The annotation policy is
`docs/bit_segmentation_guidelines.md`.

## Methods to compare

### A. Fixed-window baseline

Use the existing `fixed_word_window_v0` output. It is deterministic and cheap,
but it is expected to split premises at arbitrary lengths.

### B. Pause-and-transition heuristic

Start with caption gaps and textual transition cues, then enforce soft length
limits. Tune gap thresholds and length penalties only on a development subset.

### C. LLM structured segmentation

Give the model ordered caption segments with stable indexes. Require structured
JSON containing only boundary segment indexes, a brief premise label, and an
optional uncertainty flag. Do not ask the model to rewrite transcript text.

At least two LLM configurations should be compared, for example:

- one complete excerpt per request;
- overlapping chunks with boundary reconciliation.

Store provider, model, prompt version, parameters, token counts, latency, and
estimated cost for every run. Prompts and model outputs must be versioned.

## Dataset split

Before tuning, assign whole performances—not individual excerpts—to:

- development: 6 performances / 12 excerpts;
- validation: 2 performances / 4 excerpts;
- test: 2 performances / 4 excerpts.

Use a deterministic, versioned assignment. Keeping a performer entirely within
one split reduces leakage from style and repeated premises. Do not inspect test
labels while tuning.

The current 20-excerpt set is suitable for an initial method decision and
pipeline test. Expand it before making a strong scientific claim.

## Metrics

Report all metrics on the scored region and macro-average across performances.

### Primary

**Tolerant boundary F1:** a predicted boundary matches one reference boundary
when it falls within one caption segment or three seconds. Matching is
one-to-one. Report precision, recall, and F1.

### Secondary

- exact boundary precision, recall, and F1;
- over-segmentation rate: unmatched predicted boundaries per reference bit;
- under-segmentation rate: unmatched reference boundaries per reference bit;
- excluded-material accuracy;
- percentage of generated bits outside the preferred 80–800 word range;
- transcript-word coverage;
- latency and cost per 1,000 transcript words.

### Human quality audit

Blindly rate a sample of resulting bits from 1–5 on:

- one coherent primary premise;
- complete enough setup and payoff;
- absence of unrelated neighboring material;
- usefulness as an independently retrievable search result.

Boundary F1 is the selection metric. Human coherence, cost, and latency are
reported as guardrails; they must not be collapsed into an undocumented single
score.

## Selection rule

Select the simplest method that:

1. has the highest validation tolerant-boundary F1 within uncertainty;
2. does not materially reduce human coherence;
3. meets the product's cost and latency budget;
4. preserves stable source indexes and timestamps;
5. produces deterministic stable IDs from source ID, segmentation version, and
   boundaries.

Evaluate the chosen configuration once on the untouched test split. Record
failures and qualitative examples, not only the aggregate score.

## Next implementation after annotation

1. Import the reviewed workbook into the JSON contract.
2. Add baseline and LLM segmentation runners with a shared output schema.
3. Implement exact and tolerant one-to-one boundary matching.
4. Store experiment runs and per-example results in DuckDB.
5. Select a version and replace provisional windows with versioned production
   bit records.
