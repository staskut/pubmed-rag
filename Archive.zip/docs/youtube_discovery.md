# Official YouTube candidate discovery

This command searches only metadata through the official YouTube Data API. It
does not download videos or captions.

## Configure access

1. Create a Google Cloud project.
2. Enable **YouTube Data API v3**.
3. Create an API key and restrict it to the YouTube Data API.
4. Put the key in the gitignored `.env` file:

```bash
YOUTUBE_API_KEY='your-key'
```

An exported `YOUTUBE_API_KEY` environment variable takes precedence over
`.env`. Do not put the key in the repository, discovery configuration, or
command-line arguments.

## Run

```bash
.venv/bin/python -m pip install -e '.[dev]'
.venv/bin/discover-youtube
```

The default configuration is
`config/discovery/youtube_cc_candidates.json`. The default output is
`artifacts/discovery/youtube_cc_candidates.csv`. A more conservative
title/format shortlist is also written to
`artifacts/discovery/youtube_cc_shortlist.csv`.

To retain candidates that failed the second verification stage for auditing:

```bash
.venv/bin/discover-youtube --include-rejected
```

## Filtering and verification

Every `search.list` request applies:

- `type=video`;
- `videoLicense=creativeCommon`;
- `videoCaption=closedCaption`;
- `videoEmbeddable=true`;
- `relevanceLanguage=en`;
- a configured medium or long duration and publication range.

The script deduplicates the results, calls `videos.list` in batches, and accepts
only records for which:

- `status.license == creativeCommon`;
- `contentDetails.caption == true`;
- `status.privacyStatus == public`;
- `status.embeddable == true`.

The CSV preserves every query, search region, target market, duration filter,
and the best discovery rank associated with a candidate.

YouTube query relevance is noisy even with all official filters applied. The
script therefore adds a transparent subject score based on stand-up/performance
signals in the title and description, while penalizing obvious podcasts,
interviews, reactions, movies, tutorials, and similar formats. This produces a
smaller review shortlist without deleting the full official-filter audit set.
An explicitly non-English `defaultAudioLanguage` also excludes a row from the
shortlist; missing language metadata remains reviewable and is flagged. The
heuristic is not a classifier and must not replace manual review.

## What the CSV does not prove

These are candidates, not approved corpus sources. The official fields do not
prove that:

- the spoken language and caption track are English;
- captions are manual, complete, or high quality;
- the uploader owns every element of the performance;
- the comedian belongs to the target market;
- the content is a single-comedian stand-up performance;
- transcript text can be downloaded through the official API.

Consequently every row starts with:

- `manual_review_status=pending`;
- `rights_status=candidate_cc_by_unverified`;
- `transcript_acquisition_status=pending`.

Only a reviewed candidate should be copied into the ingestion source manifest.
The subsequent transcript adapter must preserve the source URL, exact license
metadata, retrieval date, attribution, and transcript hash.
