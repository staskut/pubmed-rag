"""Source discovery using official provider APIs."""

