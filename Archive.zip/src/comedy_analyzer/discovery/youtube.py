"""Discover captioned Creative Commons videos with the YouTube Data API.

This module retrieves metadata only. It does not download caption or video
content, and it never treats YouTube's self-declared license field as proof that
the uploader owns every right needed by this project.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Protocol
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


API_ROOT = "https://www.googleapis.com/youtube/v3"
RETRYABLE_HTTP_CODES = {429, 500, 502, 503, 504}
CSV_FIELDS = [
    "video_id",
    "source_url",
    "title",
    "description",
    "channel_title",
    "channel_id",
    "published_at",
    "default_audio_language",
    "default_language",
    "duration_iso8601",
    "duration_seconds",
    "has_captions",
    "license",
    "privacy_status",
    "embeddable",
    "licensed_content",
    "discovery_queries",
    "search_region_codes",
    "target_markets",
    "requested_durations",
    "best_search_rank",
    "discovered_at",
    "official_filter_passed",
    "filter_rejection_reasons",
    "subject_relevance_score",
    "subject_relevance_signals",
    "language_metadata_passed",
    "subject_filter_passed",
    "rights_review_flags",
    "manual_review_status",
    "rights_status",
    "transcript_acquisition_status",
    "review_notes",
]


class DiscoveryClient(Protocol):
    def search(self, params: dict[str, Any]) -> dict[str, Any]:
        """Return one official search.list response."""

    def videos(self, video_ids: list[str]) -> dict[str, Any]:
        """Return one official videos.list response."""


class YouTubeApiError(RuntimeError):
    """A redacted YouTube Data API request failure."""


class YouTubeDataApiClient:
    """Small dependency-free client for the two required official endpoints."""

    def __init__(
        self,
        api_key: str,
        *,
        timeout_seconds: float = 30.0,
        max_attempts: int = 3,
    ) -> None:
        if not api_key:
            raise ValueError("YouTube API key cannot be empty")
        self._api_key = api_key
        self._timeout_seconds = timeout_seconds
        self._max_attempts = max_attempts

    def search(self, params: dict[str, Any]) -> dict[str, Any]:
        return self._get("search", params)

    def videos(self, video_ids: list[str]) -> dict[str, Any]:
        return self._get(
            "videos",
            {
                "part": "snippet,contentDetails,status",
                "id": ",".join(video_ids),
                "maxResults": 50,
            },
        )

    def _get(self, resource: str, params: dict[str, Any]) -> dict[str, Any]:
        request_params = {**params, "key": self._api_key}
        url = f"{API_ROOT}/{resource}?{urlencode(request_params)}"
        request = Request(
            url,
            headers={
                "Accept": "application/json",
                "User-Agent": "standup-comedy-analyzer/0.1",
            },
        )

        for attempt in range(1, self._max_attempts + 1):
            try:
                with urlopen(request, timeout=self._timeout_seconds) as response:
                    return json.loads(response.read().decode("utf-8"))
            except HTTPError as exc:
                if (
                    exc.code in RETRYABLE_HTTP_CODES
                    and attempt < self._max_attempts
                ):
                    time.sleep(2 ** (attempt - 1))
                    continue
                detail = _read_google_error(exc)
                raise YouTubeApiError(
                    f"YouTube Data API {resource} request failed "
                    f"with HTTP {exc.code}: {detail}"
                ) from exc
            except URLError as exc:
                if attempt < self._max_attempts:
                    time.sleep(2 ** (attempt - 1))
                    continue
                raise YouTubeApiError(
                    f"YouTube Data API {resource} request could not connect"
                ) from exc

        raise AssertionError("unreachable")


def _read_google_error(exc: HTTPError) -> str:
    """Extract an API error without including the request URL or API key."""

    try:
        payload = json.loads(exc.read().decode("utf-8"))
        message = payload.get("error", {}).get("message")
        return str(message) if message else "unknown API error"
    except (json.JSONDecodeError, UnicodeDecodeError):
        return "unknown API error"


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def load_config(path: Path) -> dict[str, Any]:
    config = json.loads(path.read_text(encoding="utf-8"))
    if config.get("schema_version") != 1:
        raise ValueError("Discovery config schema_version must be 1")
    if config.get("relevance_language") != "en":
        raise ValueError("The MVP discovery language must be 'en'")

    durations = config.get("durations")
    if not durations or any(
        duration not in {"medium", "long"} for duration in durations
    ):
        raise ValueError("durations must contain only 'medium' and/or 'long'")

    max_results = config.get("max_results_per_search")
    if not isinstance(max_results, int) or not 1 <= max_results <= 500:
        raise ValueError("max_results_per_search must be between 1 and 500")

    searches = config.get("searches")
    if not isinstance(searches, list) or not searches:
        raise ValueError("Discovery config must contain searches")
    for search in searches:
        missing = {"query", "region_code", "target_market"} - set(search)
        if missing:
            raise ValueError(
                "Search is missing fields: " + ", ".join(sorted(missing))
            )
        if not re.fullmatch(r"[A-Z]{2}", search["region_code"]):
            raise ValueError(
                f"Invalid region_code: {search['region_code']!r}"
            )
    return config


def load_env_value(path: Path, key: str) -> str | None:
    """Read one key from a dotenv file without executing shell contents."""

    if not path.exists():
        return None
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line.removeprefix("export ").lstrip()
        name, separator, value = line.partition("=")
        if not separator or name.strip() != key:
            continue
        value = value.strip()
        if (
            len(value) >= 2
            and value[0] == value[-1]
            and value[0] in {"'", '"'}
        ):
            value = value[1:-1]
        return value or None
    return None


def iso8601_duration_seconds(value: str) -> int | None:
    """Convert YouTube's ISO-8601 day/time duration subset to seconds."""

    match = re.fullmatch(
        r"P(?:(?P<days>\d+)D)?T"
        r"(?:(?P<hours>\d+)H)?"
        r"(?:(?P<minutes>\d+)M)?"
        r"(?:(?P<seconds>\d+)S)?",
        value,
    )
    if not match:
        return None
    parts = {
        name: int(number or 0) for name, number in match.groupdict().items()
    }
    return (
        parts["days"] * 86_400
        + parts["hours"] * 3_600
        + parts["minutes"] * 60
        + parts["seconds"]
    )


def discover_candidates(
    config: dict[str, Any],
    client: DiscoveryClient,
    *,
    discovered_at: str | None = None,
) -> list[dict[str, Any]]:
    """Search, deduplicate, re-verify, and return audit-ready candidate rows."""

    timestamp = discovered_at or utc_now()
    candidates: dict[str, dict[str, Any]] = {}

    for search_spec in config["searches"]:
        for duration in config["durations"]:
            _collect_search_results(
                client=client,
                config=config,
                search_spec=search_spec,
                duration=duration,
                candidates=candidates,
            )

    details: dict[str, dict[str, Any]] = {}
    candidate_ids = list(candidates)
    for start in range(0, len(candidate_ids), 50):
        response = client.videos(candidate_ids[start : start + 50])
        for item in response.get("items", []):
            details[item["id"]] = item

    rows = [
        _build_row(video_id, provenance, details.get(video_id), timestamp)
        for video_id, provenance in candidates.items()
    ]
    return sorted(
        rows,
        key=lambda row: (
            not row["official_filter_passed"],
            row["best_search_rank"],
            row["published_at"],
            row["video_id"],
        ),
    )


def _collect_search_results(
    *,
    client: DiscoveryClient,
    config: dict[str, Any],
    search_spec: dict[str, str],
    duration: str,
    candidates: dict[str, dict[str, Any]],
) -> None:
    remaining = config["max_results_per_search"]
    page_token: str | None = None
    rank = 0

    while remaining > 0:
        params: dict[str, Any] = {
            "part": "snippet",
            "type": "video",
            "q": search_spec["query"],
            "regionCode": search_spec["region_code"],
            "relevanceLanguage": config["relevance_language"],
            "videoCaption": "closedCaption",
            "videoLicense": "creativeCommon",
            "videoEmbeddable": "true",
            "videoDuration": duration,
            "maxResults": min(50, remaining),
        }
        if config.get("published_after"):
            params["publishedAfter"] = config["published_after"]
        if config.get("published_before"):
            params["publishedBefore"] = config["published_before"]
        if page_token:
            params["pageToken"] = page_token

        response = client.search(params)
        items = response.get("items", [])
        for item in items:
            video_id = item.get("id", {}).get("videoId")
            if not video_id:
                continue
            rank += 1
            provenance = candidates.setdefault(
                video_id,
                {
                    "queries": set(),
                    "region_codes": set(),
                    "target_markets": set(),
                    "durations": set(),
                    "best_rank": rank,
                },
            )
            provenance["queries"].add(search_spec["query"])
            provenance["region_codes"].add(search_spec["region_code"])
            provenance["target_markets"].add(search_spec["target_market"])
            provenance["durations"].add(duration)
            provenance["best_rank"] = min(provenance["best_rank"], rank)

        remaining -= len(items)
        page_token = response.get("nextPageToken")
        if not items or not page_token:
            break


def _build_row(
    video_id: str,
    provenance: dict[str, Any],
    video: dict[str, Any] | None,
    discovered_at: str,
) -> dict[str, Any]:
    if video is None:
        return {
            **{field: "" for field in CSV_FIELDS},
            "video_id": video_id,
            "source_url": f"https://www.youtube.com/watch?v={video_id}",
            "discovery_queries": _join(provenance["queries"]),
            "search_region_codes": _join(provenance["region_codes"]),
            "target_markets": _join(provenance["target_markets"]),
            "requested_durations": _join(provenance["durations"]),
            "best_search_rank": provenance["best_rank"],
            "discovered_at": discovered_at,
            "official_filter_passed": False,
            "filter_rejection_reasons": "video_details_missing",
            "subject_relevance_score": 0,
            "subject_relevance_signals": "",
            "language_metadata_passed": False,
            "subject_filter_passed": False,
            "rights_review_flags": "",
            "manual_review_status": "pending",
            "rights_status": "candidate_unverified",
            "transcript_acquisition_status": "pending",
        }

    snippet = video.get("snippet", {})
    content = video.get("contentDetails", {})
    status = video.get("status", {})
    rejection_reasons: list[str] = []
    if status.get("license") != "creativeCommon":
        rejection_reasons.append("not_creative_common")
    if content.get("caption") != "true":
        rejection_reasons.append("captions_not_available")
    if status.get("privacyStatus") != "public":
        rejection_reasons.append("not_public")
    if status.get("embeddable") is not True:
        rejection_reasons.append("not_embeddable")

    duration = content.get("duration", "")
    relevance_score, relevance_signals, subject_passed = _subject_relevance(
        snippet.get("title", ""),
        snippet.get("description", ""),
        snippet.get("channelTitle", ""),
    )
    audio_language = snippet.get("defaultAudioLanguage", "")
    language_metadata_passed = (
        not audio_language or audio_language.lower().startswith("en")
    )
    if not audio_language:
        relevance_signals.append("audio_language_unset")
    elif not language_metadata_passed:
        relevance_signals.append("audio_language_not_english")
        subject_passed = False
    return {
        "video_id": video_id,
        "source_url": f"https://www.youtube.com/watch?v={video_id}",
        "title": snippet.get("title", ""),
        "description": snippet.get("description", ""),
        "channel_title": snippet.get("channelTitle", ""),
        "channel_id": snippet.get("channelId", ""),
        "published_at": snippet.get("publishedAt", ""),
        "default_audio_language": audio_language,
        "default_language": snippet.get("defaultLanguage", ""),
        "duration_iso8601": duration,
        "duration_seconds": iso8601_duration_seconds(duration) or "",
        "has_captions": content.get("caption", ""),
        "license": status.get("license", ""),
        "privacy_status": status.get("privacyStatus", ""),
        "embeddable": status.get("embeddable", ""),
        "licensed_content": content.get("licensedContent", ""),
        "discovery_queries": _join(provenance["queries"]),
        "search_region_codes": _join(provenance["region_codes"]),
        "target_markets": _join(provenance["target_markets"]),
        "requested_durations": _join(provenance["durations"]),
        "best_search_rank": provenance["best_rank"],
        "discovered_at": discovered_at,
        "official_filter_passed": not rejection_reasons,
        "filter_rejection_reasons": "|".join(rejection_reasons),
        "subject_relevance_score": relevance_score,
        "subject_relevance_signals": "|".join(relevance_signals),
        "language_metadata_passed": language_metadata_passed,
        "subject_filter_passed": subject_passed,
        "rights_review_flags": "|".join(
            _rights_review_flags(
                snippet.get("title", ""),
                snippet.get("channelTitle", ""),
            )
        ),
        "manual_review_status": "pending",
        "rights_status": "candidate_cc_by_unverified",
        "transcript_acquisition_status": "pending",
        "review_notes": "",
    }


def _join(values: set[str]) -> str:
    return "|".join(sorted(values))


def _subject_relevance(
    title: str, description: str, channel_title: str
) -> tuple[int, list[str], bool]:
    """Conservatively identify likely performance videos for review."""

    title_lower = title.lower()
    description_lower = description.lower()
    channel_lower = channel_title.lower()
    score = 0
    signals: list[str] = []
    strong_signal = False

    if re.search(r"\bstand[ -]?up\b", title_lower):
        score += 5
        strong_signal = True
        signals.append("title_stand_up")
    if re.search(
        r"\b(comedy special|full special|live from the belly room)\b",
        title_lower,
    ):
        score += 4
        strong_signal = True
        signals.append("title_performance_format")
    if re.search(r"\bstand[ -]?up\b", description_lower):
        score += 2
        signals.append("description_stand_up")
    if re.search(r"\bcomedy\b", title_lower):
        score += 1
        signals.append("title_comedy")

    negative_pattern = re.compile(
        r"\b("
        r"podcast|interview|reaction|tutorial|full movie|tv series|"
        r"parliament|audiobook|teatime|explained|review|documentary|"
        r"compilation"
        r")\b"
    )
    if negative_pattern.search(title_lower) or negative_pattern.search(
        channel_lower
    ):
        score -= 6
        signals.append("non_performance_format")

    return score, signals, bool(strong_signal and score >= 5)


def _rights_review_flags(title: str, channel_title: str) -> list[str]:
    combined = f"{title} {channel_title}".lower()
    flags: list[str] = []
    if re.search(r"\b(bootleg|reupload|fan channel|footage)\b", combined):
        flags.append("possible_reupload_signal")
    if re.search(r"\b(compilation|best of|moments)\b", combined):
        flags.append("possible_compilation")
    return flags


def write_csv(
    rows: list[dict[str, Any]],
    output_path: Path,
    *,
    include_rejected: bool,
) -> int:
    selected = (
        rows
        if include_rejected
        else [row for row in rows if row["official_filter_passed"]]
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(selected)
    return len(selected)


def write_shortlist_csv(
    rows: list[dict[str, Any]], output_path: Path
) -> int:
    selected = [
        row
        for row in rows
        if row["official_filter_passed"] and row["subject_filter_passed"]
    ]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(selected)
    return len(selected)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Discover captioned Creative Commons stand-up candidates using "
            "the official YouTube Data API."
        )
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("config/discovery/youtube_cc_candidates.json"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("artifacts/discovery/youtube_cc_candidates.csv"),
    )
    parser.add_argument(
        "--shortlist-output",
        type=Path,
        default=Path("artifacts/discovery/youtube_cc_shortlist.csv"),
    )
    parser.add_argument(
        "--api-key-env",
        default="YOUTUBE_API_KEY",
        help="Environment variable containing the API key.",
    )
    parser.add_argument(
        "--env-file",
        type=Path,
        default=Path(".env"),
        help="Dotenv fallback used when the API-key environment variable is unset.",
    )
    parser.add_argument(
        "--include-rejected",
        action="store_true",
        help="Include candidates that fail videos.list re-verification.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    api_key = os.environ.get(args.api_key_env) or load_env_value(
        args.env_file, args.api_key_env
    )
    if not api_key:
        print(
            "Discovery failed: set "
            f"{args.api_key_env} in the environment or {args.env_file}.",
            file=sys.stderr,
        )
        return 2

    try:
        config = load_config(args.config)
        rows = discover_candidates(config, YouTubeDataApiClient(api_key))
        written = write_csv(
            rows,
            args.output,
            include_rejected=args.include_rejected,
        )
        shortlisted = write_shortlist_csv(rows, args.shortlist_output)
    except (OSError, ValueError, YouTubeApiError) as exc:
        print(f"Discovery failed: {exc}", file=sys.stderr)
        return 1

    eligible = sum(row["official_filter_passed"] for row in rows)
    print(
        json.dumps(
            {
                "unique_candidates": len(rows),
                "official_filter_passed": eligible,
                "rows_written": written,
                "output": str(args.output),
                "shortlist_rows_written": shortlisted,
                "shortlist_output": str(args.shortlist_output),
                "manual_review_required": True,
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
