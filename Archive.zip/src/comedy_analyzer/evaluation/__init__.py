"""Offline evaluation data and metrics."""
