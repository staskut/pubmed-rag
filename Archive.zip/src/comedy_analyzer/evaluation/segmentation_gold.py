"""Create a deterministic, local-only bit-boundary annotation sample."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

from comedy_analyzer.ingestion.youtube import read_manifest
from comedy_analyzer.pipelines.corpus import iter_jsonl


SCHEMA_VERSION = "segmentation_gold_v1"
SAMPLER_VERSION = "balanced_anchor_with_context_v1"
ANNOTATION_POLICY_VERSION = "bit_boundary_v1"


@dataclass(frozen=True)
class SampleSegment:
    row_id: str
    source_segment_index: int
    start_seconds: float
    end_seconds: float
    text: str
    word_count: int
    in_evaluation_region: bool
    boundary_before: str = ""
    segment_action: str = ""
    boundary_reason: str = ""
    confidence: str = ""
    annotator_notes: str = ""


@dataclass(frozen=True)
class Sample:
    sample_id: str
    source_id: str
    video_id: str
    performer: str
    title: str
    source_url: str
    sample_sequence: int
    sample_start_segment: int
    sample_end_segment: int
    evaluation_start_segment: int
    evaluation_end_segment: int
    sample_word_count: int
    evaluation_word_count: int
    segments: list[SampleSegment]


def _word_count(segment: dict[str, Any]) -> int:
    return len(str(segment["text"]).split())


def _segment_at_word(
    segments: list[dict[str, Any]],
    word_offset: int,
) -> int:
    cumulative = 0
    for index, segment in enumerate(segments):
        cumulative += _word_count(segment)
        if cumulative > word_offset:
            return index
    return len(segments) - 1


def _stable_jitter(
    video_id: str,
    sample_sequence: int,
    seed: int,
    *,
    amplitude: float = 0.04,
) -> float:
    digest = hashlib.sha256(
        f"{seed}:{video_id}:{sample_sequence}".encode("utf-8")
    ).digest()
    unit = int.from_bytes(digest[:8], "big") / (2**64 - 1)
    return (unit * 2.0 - 1.0) * amplitude


def _expand_by_words(
    segments: list[dict[str, Any]],
    start_index: int,
    end_index: int,
    context_words: int,
) -> tuple[int, int]:
    before_words = 0
    sample_start = start_index
    while sample_start > 0 and before_words < context_words:
        sample_start -= 1
        before_words += _word_count(segments[sample_start])

    after_words = 0
    sample_end = end_index
    while sample_end < len(segments) - 1 and after_words < context_words:
        sample_end += 1
        after_words += _word_count(segments[sample_end])
    return sample_start, sample_end


def sample_source(
    source: dict[str, Any],
    segments: list[dict[str, Any]],
    *,
    samples_per_source: int,
    target_words: int,
    context_words: int,
    seed: int,
) -> list[Sample]:
    """Take balanced deterministic excerpts from one transcript."""

    if not segments:
        raise ValueError(f"No segments found for {source['video_id']}")
    if samples_per_source < 1:
        raise ValueError("samples_per_source must be at least 1")
    if target_words < 80:
        raise ValueError("target_words must be at least 80")
    if context_words < 0:
        raise ValueError("context_words cannot be negative")

    total_words = sum(_word_count(segment) for segment in segments)
    required_words = target_words + 2 * context_words
    if total_words < required_words:
        raise ValueError(
            f"{source['video_id']} has {total_words} words; "
            f"at least {required_words} are required"
        )

    planned_ranges: list[tuple[int, int, int, int]] = []
    for sample_sequence in range(1, samples_per_source + 1):
        base_fraction = sample_sequence / (samples_per_source + 1)
        center_fraction = min(
            0.9,
            max(
                0.1,
                base_fraction
                + _stable_jitter(
                    source["video_id"], sample_sequence, seed
                ),
            ),
        )
        center_word = round(total_words * center_fraction)
        target_start_word = max(0, center_word - target_words // 2)
        target_end_word = min(
            total_words - 1, target_start_word + target_words - 1
        )
        evaluation_start = _segment_at_word(segments, target_start_word)
        evaluation_end = _segment_at_word(segments, target_end_word)
        sample_start, sample_end = _expand_by_words(
            segments,
            evaluation_start,
            evaluation_end,
            context_words,
        )
        planned_ranges.append(
            (
                sample_start,
                sample_end,
                evaluation_start,
                evaluation_end,
            )
        )

    # Context is useful for judging a central boundary, but annotating the same
    # caption twice wastes reviewer time. Split overlapping context between
    # adjacent evaluation regions while leaving the scored regions untouched.
    for index in range(len(planned_ranges) - 1):
        current = planned_ranges[index]
        following = planned_ranges[index + 1]
        if current[3] >= following[2]:
            raise ValueError(
                f"Evaluation regions overlap for {source['video_id']}; "
                "reduce samples_per_source or target_words"
            )
        if current[1] >= following[0]:
            split = (current[3] + following[2]) // 2
            planned_ranges[index] = (
                current[0],
                split,
                current[2],
                current[3],
            )
            planned_ranges[index + 1] = (
                split + 1,
                following[1],
                following[2],
                following[3],
            )

    samples: list[Sample] = []
    for sample_sequence, planned in enumerate(planned_ranges, start=1):
        sample_start, sample_end, evaluation_start, evaluation_end = planned
        selected = segments[sample_start : sample_end + 1]
        sample_id = (
            f"{source['video_id']}-seg-gold-v1-{sample_sequence:02d}"
        )
        sample_segments = [
            SampleSegment(
                row_id=f"{sample_id}:{segment['segment_index']:05d}",
                source_segment_index=int(segment["segment_index"]),
                start_seconds=float(segment["start_seconds"]),
                end_seconds=float(segment["end_seconds"]),
                text=str(segment["text"]),
                word_count=_word_count(segment),
                in_evaluation_region=(
                    evaluation_start <= absolute_index <= evaluation_end
                ),
            )
            for absolute_index, segment in enumerate(
                selected, start=sample_start
            )
        ]
        samples.append(
            Sample(
                sample_id=sample_id,
                source_id=f"youtube:{source['video_id']}",
                video_id=source["video_id"],
                performer=source["performer"],
                title=source["title"],
                source_url=source["source_url"],
                sample_sequence=sample_sequence,
                sample_start_segment=int(
                    segments[sample_start]["segment_index"]
                ),
                sample_end_segment=int(
                    segments[sample_end]["segment_index"]
                ),
                evaluation_start_segment=int(
                    segments[evaluation_start]["segment_index"]
                ),
                evaluation_end_segment=int(
                    segments[evaluation_end]["segment_index"]
                ),
                sample_word_count=sum(
                    segment.word_count for segment in sample_segments
                ),
                evaluation_word_count=sum(
                    segment.word_count
                    for segment in sample_segments
                    if segment.in_evaluation_region
                ),
                segments=sample_segments,
            )
        )
    return samples


def build_gold_template(
    sources: Iterable[dict[str, Any]],
    *,
    processed_dir: Path,
    samples_per_source: int,
    target_words: int,
    context_words: int,
    seed: int,
) -> dict[str, Any]:
    samples: list[Sample] = []
    for source in sources:
        segment_path = (
            processed_dir / f"{source['video_id']}.segments.jsonl"
        )
        if not segment_path.exists():
            raise FileNotFoundError(
                f"Missing processed transcript: {segment_path}"
            )
        samples.extend(
            sample_source(
                source,
                list(iter_jsonl(segment_path)),
                samples_per_source=samples_per_source,
                target_words=target_words,
                context_words=context_words,
                seed=seed,
            )
        )

    return {
        "schema_version": SCHEMA_VERSION,
        "sampler_version": SAMPLER_VERSION,
        "annotation_policy_version": ANNOTATION_POLICY_VERSION,
        "seed": seed,
        "parameters": {
            "samples_per_source": samples_per_source,
            "target_words": target_words,
            "context_words_each_side": context_words,
        },
        "samples": [asdict(sample) for sample in samples],
    }


def _manifest_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_outputs(
    template: dict[str, Any],
    *,
    manifest_hash: str,
    output_dir: Path,
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    template = {**template, "source_manifest_hash": manifest_hash}
    json_path = output_dir / "segmentation_gold_v1.template.json"
    csv_path = output_dir / "segmentation_gold_v1.annotation_rows.csv"
    summary_path = output_dir / "segmentation_gold_v1.summary.json"

    json_path.write_text(
        json.dumps(template, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    fieldnames = [
        "row_id",
        "sample_id",
        "source_id",
        "video_id",
        "performer",
        "title",
        "source_url",
        "source_segment_index",
        "start_seconds",
        "end_seconds",
        "word_count",
        "in_evaluation_region",
        "text",
        "boundary_before",
        "segment_action",
        "boundary_reason",
        "confidence",
        "annotator_notes",
    ]
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for sample in template["samples"]:
            for segment in sample["segments"]:
                writer.writerow(
                    {
                        **{
                            key: sample[key]
                            for key in (
                                "sample_id",
                                "source_id",
                                "video_id",
                                "performer",
                                "title",
                                "source_url",
                            )
                        },
                        **segment,
                    }
                )

    samples = template["samples"]
    summary = {
        "schema_version": template["schema_version"],
        "source_manifest_hash": manifest_hash,
        "sample_count": len(samples),
        "performance_count": len(
            {sample["source_id"] for sample in samples}
        ),
        "annotation_row_count": sum(
            len(sample["segments"]) for sample in samples
        ),
        "sample_word_count": sum(
            sample["sample_word_count"] for sample in samples
        ),
        "evaluation_word_count": sum(
            sample["evaluation_word_count"] for sample in samples
        ),
        "template_path": str(json_path),
        "annotation_rows_path": str(csv_path),
    }
    summary_path.write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    return summary


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Create a deterministic local bit-boundary annotation sample."
        )
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=Path("config/sources/youtube_cc_reviewed.json"),
    )
    parser.add_argument(
        "--processed-dir",
        type=Path,
        default=Path("data/processed/youtube"),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("data/annotations/segmentation_gold_v1"),
    )
    parser.add_argument("--samples-per-source", type=int, default=2)
    parser.add_argument("--target-words", type=int, default=220)
    parser.add_argument("--context-words", type=int, default=60)
    parser.add_argument("--seed", type=int, default=20260725)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        sources = read_manifest(args.manifest)
        template = build_gold_template(
            sources,
            processed_dir=args.processed_dir,
            samples_per_source=args.samples_per_source,
            target_words=args.target_words,
            context_words=args.context_words,
            seed=args.seed,
        )
        result = write_outputs(
            template,
            manifest_hash=_manifest_hash(args.manifest),
            output_dir=args.output_dir,
        )
    except Exception as exc:
        print(f"Segmentation sample failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
