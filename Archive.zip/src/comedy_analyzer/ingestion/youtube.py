"""Manifest-gated YouTube transcript ingestion spike.

The command deliberately separates immutable raw acquisition from deterministic
normalization. Fetched transcript text is written only to gitignored folders.
"""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import re
import sys
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterable, Protocol


ALLOWED_RIGHTS_STATUSES = {"approved_cc_by", "permission_on_file"}
TEST_ONLY_RIGHTS_STATUS = "test_only_unverified"
DEFAULT_LANGUAGES = ("en", "en-US", "en-GB")


class TranscriptAdapter(Protocol):
    """The replaceable boundary around the unofficial YouTube endpoint."""

    def fetch(self, video_id: str, languages: list[str]) -> dict[str, Any]:
        """Return transcript metadata and raw timestamped snippets."""


class YouTubeTranscriptAdapter:
    """Adapter backed by youtube-transcript-api."""

    def fetch(self, video_id: str, languages: list[str]) -> dict[str, Any]:
        from youtube_transcript_api import YouTubeTranscriptApi

        transcript_list = YouTubeTranscriptApi().list(video_id)
        transcript = self._select_transcript(transcript_list, languages)
        fetched = transcript.fetch()
        return {
            "language": transcript.language,
            "language_code": transcript.language_code,
            "is_generated": transcript.is_generated,
            "is_translatable": transcript.is_translatable,
            "snippets": fetched.to_raw_data(),
        }

    @staticmethod
    def _select_transcript(transcript_list: Any, languages: list[str]) -> Any:
        try:
            return transcript_list.find_manually_created_transcript(languages)
        except Exception:
            return transcript_list.find_generated_transcript(languages)


@dataclass(frozen=True)
class CanonicalSegment:
    source_id: str
    video_id: str
    segment_index: int
    text: str
    start_seconds: float
    duration_seconds: float
    end_seconds: float
    language_code: str
    is_generated: bool
    content_hash: str


@dataclass(frozen=True)
class BitCandidate:
    bit_id: str
    source_id: str
    video_id: str
    sequence: int
    text: str
    start_seconds: float
    end_seconds: float
    word_count: int
    source_segment_start: int
    source_segment_end: int
    segmentation_method: str
    content_hash: str


def utc_now() -> str:
    return datetime.now(UTC).isoformat()


def sha256_json(value: Any) -> str:
    encoded = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def normalize_text(value: str) -> str:
    return re.sub(r"\s+", " ", html.unescape(value)).strip()


def read_manifest(path: Path) -> list[dict[str, Any]]:
    manifest = json.loads(path.read_text(encoding="utf-8"))
    if manifest.get("schema_version") != 1:
        raise ValueError("Manifest schema_version must be 1")
    sources = manifest.get("sources")
    if not isinstance(sources, list) or not sources:
        raise ValueError("Manifest must contain a non-empty sources list")

    seen: set[str] = set()
    required = {
        "video_id",
        "title",
        "performer",
        "source_url",
        "spoken_language",
        "rights_status",
        "license",
        "approved_for_public_display",
    }
    for source in sources:
        missing = required - set(source)
        if missing:
            raise ValueError(
                f"Source is missing required fields: {', '.join(sorted(missing))}"
            )
        video_id = source["video_id"]
        if video_id in seen:
            raise ValueError(f"Duplicate video_id: {video_id}")
        if not re.fullmatch(r"[\w-]{11}", video_id):
            raise ValueError(f"Invalid YouTube video_id: {video_id}")
        if source["spoken_language"] != "en":
            raise ValueError(f"MVP accepts English sources only: {video_id}")
        seen.add(video_id)
    return sources


def assert_ingestion_allowed(
    source: dict[str, Any], *, allow_test_only: bool
) -> None:
    rights_status = source["rights_status"]
    if rights_status in ALLOWED_RIGHTS_STATUSES:
        return
    if rights_status == TEST_ONLY_RIGHTS_STATUS and allow_test_only:
        return
    raise PermissionError(
        f"{source['video_id']} has rights_status={rights_status!r}. "
        "Use --allow-test-only only for a local, non-distributable smoke test."
    )


def canonicalize(
    source: dict[str, Any], raw: dict[str, Any]
) -> list[CanonicalSegment]:
    source_id = f"youtube:{source['video_id']}"
    segments: list[CanonicalSegment] = []
    for index, snippet in enumerate(raw["transcript"]["snippets"]):
        text = normalize_text(snippet.get("text", ""))
        if not text:
            continue
        start = round(float(snippet["start"]), 3)
        duration = round(float(snippet["duration"]), 3)
        segments.append(
            CanonicalSegment(
                source_id=source_id,
                video_id=source["video_id"],
                segment_index=index,
                text=text,
                start_seconds=start,
                duration_seconds=duration,
                end_seconds=round(start + duration, 3),
                language_code=raw["transcript"]["language_code"],
                is_generated=bool(raw["transcript"]["is_generated"]),
                content_hash=sha256_text(text),
            )
        )
    return segments


def make_bit_candidates(
    segments: list[CanonicalSegment],
    *,
    target_words: int = 120,
    max_words: int = 180,
    max_gap_seconds: float = 8.0,
    min_words: int = 40,
) -> list[BitCandidate]:
    """Create reviewable windows, not production-quality semantic bits."""

    if not segments:
        return []

    groups: list[list[CanonicalSegment]] = []
    current: list[CanonicalSegment] = []
    word_count = 0

    for segment in segments:
        segment_words = len(segment.text.split())
        gap = (
            segment.start_seconds - current[-1].end_seconds if current else 0.0
        )
        should_break = bool(
            current
            and (
                gap > max_gap_seconds
                or word_count >= target_words
                or word_count + segment_words > max_words
            )
        )
        if should_break:
            groups.append(current)
            current = []
            word_count = 0
        current.append(segment)
        word_count += segment_words
    if current:
        groups.append(current)

    # A long audience pause often follows the punchline, so a tiny group before
    # that pause belongs with the setup that precedes it. Merge such fragments
    # when doing so keeps the review window below the hard maximum.
    coalesced: list[list[CanonicalSegment]] = []
    for group in groups:
        group_words = sum(len(segment.text.split()) for segment in group)
        previous_words = (
            sum(len(segment.text.split()) for segment in coalesced[-1])
            if coalesced
            else 0
        )
        if (
            coalesced
            and group_words < min_words
            and previous_words + group_words <= max_words
        ):
            coalesced[-1].extend(group)
        else:
            coalesced.append(group)
    groups = coalesced

    bits: list[BitCandidate] = []
    for sequence, group in enumerate(groups):
        text = normalize_text(" ".join(segment.text for segment in group))
        bits.append(
            BitCandidate(
                bit_id=f"youtube:{group[0].video_id}:window-v0:{sequence:04d}",
                source_id=group[0].source_id,
                video_id=group[0].video_id,
                sequence=sequence,
                text=text,
                start_seconds=group[0].start_seconds,
                end_seconds=group[-1].end_seconds,
                word_count=len(text.split()),
                source_segment_start=group[0].segment_index,
                source_segment_end=group[-1].segment_index,
                segmentation_method="fixed_word_window_v0",
                content_hash=sha256_text(text),
            )
        )
    return bits


def build_qa_report(
    source: dict[str, Any],
    raw: dict[str, Any],
    segments: list[CanonicalSegment],
    bits: list[BitCandidate],
) -> dict[str, Any]:
    starts = [segment.start_seconds for segment in segments]
    duplicate_texts = len(segments) - len(
        {segment.content_hash for segment in segments}
    )
    consecutive_duplicate_texts = sum(
        segments[index].content_hash == segments[index - 1].content_hash
        for index in range(1, len(segments))
    )
    return {
        "video_id": source["video_id"],
        "source_id": f"youtube:{source['video_id']}",
        "title": source["title"],
        "performer": source["performer"],
        "rights_status": source["rights_status"],
        "approved_for_public_display": source["approved_for_public_display"],
        "retrieved_at": raw["retrieved_at"],
        "raw_content_hash": raw["raw_content_hash"],
        "language_code": raw["transcript"]["language_code"],
        "is_generated": raw["transcript"]["is_generated"],
        "raw_snippet_count": len(raw["transcript"]["snippets"]),
        "canonical_segment_count": len(segments),
        "bit_candidate_count": len(bits),
        "total_words": sum(len(segment.text.split()) for segment in segments),
        "duration_seconds": max(
            (segment.end_seconds for segment in segments), default=0.0
        ),
        "empty_segments_after_normalization": (
            len(raw["transcript"]["snippets"]) - len(segments)
        ),
        "out_of_order_segments": sum(
            starts[index] < starts[index - 1]
            for index in range(1, len(starts))
        ),
        "duplicate_segment_texts": duplicate_texts,
        "consecutive_duplicate_segment_texts": consecutive_duplicate_texts,
        "candidate_word_count_min": min(
            (bit.word_count for bit in bits), default=0
        ),
        "candidate_word_count_max": max(
            (bit.word_count for bit in bits), default=0
        ),
        "checks": {
            "has_content": bool(segments),
            "english_track": raw["transcript"]["language_code"].startswith("en"),
            "timestamps_monotonic": all(
                starts[index] >= starts[index - 1]
                for index in range(1, len(starts))
            ),
            "minimum_100_words": (
                sum(len(segment.text.split()) for segment in segments) >= 100
            ),
            "no_tiny_bit_candidates": all(bit.word_count >= 40 for bit in bits),
        },
    }


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def write_jsonl(path: Path, records: Iterable[Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for record in records:
            value = asdict(record) if hasattr(record, "__dataclass_fields__") else record
            handle.write(json.dumps(value, ensure_ascii=False) + "\n")


def ingest_source(
    source: dict[str, Any],
    *,
    data_dir: Path,
    adapter: TranscriptAdapter,
    allow_test_only: bool,
    refresh: bool,
) -> dict[str, Any]:
    assert_ingestion_allowed(source, allow_test_only=allow_test_only)
    video_id = source["video_id"]
    raw_path = data_dir / "raw" / "youtube" / f"{video_id}.json"

    if raw_path.exists() and not refresh:
        raw = json.loads(raw_path.read_text(encoding="utf-8"))
        cache_status = "hit"
    else:
        transcript = adapter.fetch(video_id, list(DEFAULT_LANGUAGES))
        raw = {
            "schema_version": 1,
            "source": source,
            "retrieved_at": utc_now(),
            "adapter": {
                "name": "youtube-transcript-api",
                "version": "1.2.4",
            },
            "transcript": transcript,
        }
        raw["raw_content_hash"] = sha256_json(raw["transcript"])
        write_json(raw_path, raw)
        cache_status = "miss"

    segments = canonicalize(source, raw)
    bits = make_bit_candidates(segments)
    qa = build_qa_report(source, raw, segments, bits)
    qa["cache_status"] = cache_status

    processed_dir = data_dir / "processed" / "youtube"
    write_jsonl(processed_dir / f"{video_id}.segments.jsonl", segments)
    write_jsonl(processed_dir / f"{video_id}.bit-candidates.jsonl", bits)
    write_json(processed_dir / f"{video_id}.qa.json", qa)
    return qa


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Fetch and normalize manifest-approved YouTube transcripts."
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=Path("config/sources/youtube_spike.json"),
    )
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    parser.add_argument(
        "--allow-test-only",
        action="store_true",
        help="Allow local ingestion of sources marked test_only_unverified.",
    )
    parser.add_argument(
        "--refresh",
        action="store_true",
        help="Ignore the local raw cache and fetch again.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        sources = read_manifest(args.manifest)
        reports = [
            ingest_source(
                source,
                data_dir=args.data_dir,
                adapter=YouTubeTranscriptAdapter(),
                allow_test_only=args.allow_test_only,
                refresh=args.refresh,
            )
            for source in sources
        ]
    except Exception as exc:
        print(f"Ingestion failed: {exc}", file=sys.stderr)
        return 1

    for report in reports:
        print(
            json.dumps(
                {
                    "video_id": report["video_id"],
                    "segments": report["canonical_segment_count"],
                    "bit_candidates": report["bit_candidate_count"],
                    "words": report["total_words"],
                    "duration_seconds": report["duration_seconds"],
                    "is_generated": report["is_generated"],
                    "cache_status": report["cache_status"],
                    "checks": report["checks"],
                },
                indent=2,
            )
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
