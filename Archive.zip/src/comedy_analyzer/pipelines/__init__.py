"""Automated data pipelines."""

