"""Load the reviewed local transcript corpus into DuckDB with dlt."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterable, Iterator
from uuid import uuid4

import dlt
import duckdb


DATASET_NAME = "corpus"


def load_manifest(path: Path) -> tuple[list[dict[str, Any]], str]:
    raw = path.read_bytes()
    manifest = json.loads(raw.decode("utf-8"))
    if manifest.get("schema_version") != 1:
        raise ValueError("Source manifest schema_version must be 1")
    sources = manifest.get("sources")
    if not isinstance(sources, list) or not sources:
        raise ValueError("Source manifest must contain a non-empty sources list")
    return sources, hashlib.sha256(raw).hexdigest()


def iter_jsonl(path: Path) -> Iterator[dict[str, Any]]:
    with path.open(encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"Invalid JSONL at {path}:{line_number}"
                ) from exc


def performance_records(
    sources: Iterable[dict[str, Any]],
) -> Iterator[dict[str, Any]]:
    for source in sources:
        yield {
            "source_id": f"youtube:{source['video_id']}",
            **source,
        }


def processed_records(
    sources: Iterable[dict[str, Any]],
    processed_dir: Path,
    suffix: str,
) -> Iterator[dict[str, Any]]:
    for source in sources:
        path = processed_dir / f"{source['video_id']}.{suffix}.jsonl"
        if not path.exists():
            raise FileNotFoundError(
                f"Missing processed data for {source['video_id']}: {path}"
            )
        yield from iter_jsonl(path)


def quality_records(
    sources: Iterable[dict[str, Any]],
    processed_dir: Path,
) -> Iterator[dict[str, Any]]:
    for source in sources:
        path = processed_dir / f"{source['video_id']}.qa.json"
        if not path.exists():
            raise FileNotFoundError(
                f"Missing QA data for {source['video_id']}: {path}"
            )
        qa = json.loads(path.read_text(encoding="utf-8"))
        checks = qa.pop("checks", {})
        yield {
            **qa,
            **{f"check_{name}": value for name, value in checks.items()},
        }


def corpus_counts(
    sources: list[dict[str, Any]],
    processed_dir: Path,
) -> dict[str, int | float]:
    qa_rows = list(quality_records(sources, processed_dir))
    return {
        "performance_count": len(sources),
        "segment_count": sum(
            int(row["canonical_segment_count"]) for row in qa_rows
        ),
        "provisional_window_count": sum(
            int(row["bit_candidate_count"]) for row in qa_rows
        ),
        "word_count": sum(int(row["total_words"]) for row in qa_rows),
        "duration_seconds": round(
            sum(float(row["duration_seconds"]) for row in qa_rows), 3
        ),
    }


def make_resources(
    *,
    sources: list[dict[str, Any]],
    processed_dir: Path,
    manifest_hash: str,
    counts: dict[str, int | float],
) -> list[Any]:
    run_id = str(uuid4())
    loaded_at = datetime.now(UTC).isoformat()

    performances = dlt.resource(
        performance_records(sources),
        name="performances",
        primary_key="source_id",
        write_disposition="merge",
    )
    segments = dlt.resource(
        processed_records(sources, processed_dir, "segments"),
        name="transcript_segments",
        primary_key=["source_id", "segment_index"],
        write_disposition="merge",
    )
    windows = dlt.resource(
        processed_records(sources, processed_dir, "bit-candidates"),
        name="bit_candidates",
        primary_key="bit_id",
        write_disposition="merge",
    )
    quality = dlt.resource(
        quality_records(sources, processed_dir),
        name="transcript_quality",
        primary_key="source_id",
        write_disposition="merge",
    )
    ingestion_runs = dlt.resource(
        [
            {
                "run_id": run_id,
                "loaded_at": loaded_at,
                "manifest_hash": manifest_hash,
                "pipeline_version": "dlt-duckdb-v1",
                **counts,
            }
        ],
        name="ingestion_runs",
        primary_key="run_id",
        write_disposition="append",
    )
    return [performances, segments, windows, quality, ingestion_runs]


def run_pipeline(
    *,
    manifest_path: Path,
    data_dir: Path,
    database_path: Path,
) -> dict[str, Any]:
    sources, manifest_hash = load_manifest(manifest_path)
    processed_dir = data_dir / "processed" / "youtube"
    counts = corpus_counts(sources, processed_dir)
    database_path.parent.mkdir(parents=True, exist_ok=True)
    pipelines_dir = data_dir / "dlt"
    pipelines_dir.mkdir(parents=True, exist_ok=True)

    pipeline = dlt.pipeline(
        pipeline_name="comedy_corpus_pipeline",
        destination=dlt.destinations.duckdb(
            credentials=str(database_path)
        ),
        dataset_name=DATASET_NAME,
        pipelines_dir=str(pipelines_dir),
    )
    load_info = pipeline.run(
        make_resources(
            sources=sources,
            processed_dir=processed_dir,
            manifest_hash=manifest_hash,
            counts=counts,
        )
    )

    table_counts = inspect_database(database_path)
    return {
        "database_path": str(database_path),
        "dataset": DATASET_NAME,
        "manifest_hash": manifest_hash,
        "load_packages": len(load_info.loads_ids),
        "table_counts": table_counts,
        "source_counts": counts,
    }


def inspect_database(database_path: Path) -> dict[str, int]:
    tables = [
        "performances",
        "transcript_segments",
        "bit_candidates",
        "transcript_quality",
        "ingestion_runs",
    ]
    with duckdb.connect(str(database_path), read_only=True) as connection:
        return {
            table: int(
                connection.execute(
                    f'SELECT COUNT(*) FROM "{DATASET_NAME}"."{table}"'
                ).fetchone()[0]
            )
            for table in tables
        }


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Load reviewed transcript data into DuckDB with dlt."
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=Path("config/sources/youtube_cc_reviewed.json"),
    )
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    parser.add_argument(
        "--database",
        type=Path,
        default=Path("data/warehouse/comedy.duckdb"),
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        result = run_pipeline(
            manifest_path=args.manifest,
            data_dir=args.data_dir,
            database_path=args.database,
        )
    except Exception as exc:
        print(f"Corpus load failed: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

