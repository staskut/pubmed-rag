from __future__ import annotations

import json
from pathlib import Path

from comedy_analyzer.pipelines.corpus import (
    inspect_database,
    run_pipeline,
)


def _write_fixture(tmp_path: Path) -> tuple[Path, Path]:
    manifest_path = tmp_path / "manifest.json"
    manifest_path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "sources": [
                    {
                        "video_id": "abcdefghijk",
                        "title": "Test",
                        "performer": "Comedian",
                        "source_url": (
                            "https://www.youtube.com/watch?v=abcdefghijk"
                        ),
                        "spoken_language": "en",
                        "rights_status": "permission_on_file",
                        "license": "direct_permission",
                        "approved_for_public_display": False,
                    }
                ],
            }
        ),
        encoding="utf-8",
    )

    processed = tmp_path / "data/processed/youtube"
    processed.mkdir(parents=True)
    (processed / "abcdefghijk.segments.jsonl").write_text(
        json.dumps(
            {
                "source_id": "youtube:abcdefghijk",
                "video_id": "abcdefghijk",
                "segment_index": 0,
                "text": "A test segment.",
                "start_seconds": 0.0,
                "duration_seconds": 2.0,
                "end_seconds": 2.0,
                "language_code": "en",
                "is_generated": False,
                "content_hash": "segment-hash",
            }
        )
        + "\n",
        encoding="utf-8",
    )
    (processed / "abcdefghijk.bit-candidates.jsonl").write_text(
        json.dumps(
            {
                "bit_id": "youtube:abcdefghijk:window-v0:0000",
                "source_id": "youtube:abcdefghijk",
                "video_id": "abcdefghijk",
                "sequence": 0,
                "text": "A test segment.",
                "start_seconds": 0.0,
                "end_seconds": 2.0,
                "word_count": 3,
                "source_segment_start": 0,
                "source_segment_end": 0,
                "segmentation_method": "fixed_word_window_v0",
                "content_hash": "window-hash",
            }
        )
        + "\n",
        encoding="utf-8",
    )
    (processed / "abcdefghijk.qa.json").write_text(
        json.dumps(
            {
                "video_id": "abcdefghijk",
                "source_id": "youtube:abcdefghijk",
                "canonical_segment_count": 1,
                "bit_candidate_count": 1,
                "total_words": 3,
                "duration_seconds": 2.0,
                "checks": {
                    "has_content": True,
                    "english_track": True,
                    "timestamps_monotonic": True,
                },
            }
        ),
        encoding="utf-8",
    )
    return manifest_path, tmp_path / "data"


def test_dlt_pipeline_is_idempotent_for_corpus_tables(
    tmp_path: Path,
) -> None:
    manifest, data_dir = _write_fixture(tmp_path)
    database = data_dir / "warehouse/test.duckdb"

    first = run_pipeline(
        manifest_path=manifest,
        data_dir=data_dir,
        database_path=database,
    )
    second = run_pipeline(
        manifest_path=manifest,
        data_dir=data_dir,
        database_path=database,
    )
    counts = inspect_database(database)

    assert first["table_counts"]["performances"] == 1
    assert second["table_counts"]["performances"] == 1
    assert counts["transcript_segments"] == 1
    assert counts["bit_candidates"] == 1
    assert counts["transcript_quality"] == 1
    assert counts["ingestion_runs"] == 2

