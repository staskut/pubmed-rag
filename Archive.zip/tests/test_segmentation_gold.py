from __future__ import annotations

import csv
import json
from pathlib import Path

from comedy_analyzer.evaluation.segmentation_gold import (
    build_gold_template,
    sample_source,
    write_outputs,
)


SOURCE = {
    "video_id": "abcdefghijk",
    "title": "Authorized test performance",
    "performer": "Test Comedian",
    "source_url": "https://www.youtube.com/watch?v=abcdefghijk",
}


def _segments(count: int = 120) -> list[dict]:
    return [
        {
            "source_id": "youtube:abcdefghijk",
            "video_id": "abcdefghijk",
            "segment_index": index,
            "text": f"segment {index} has five useful words",
            "start_seconds": float(index * 2),
            "end_seconds": float(index * 2 + 1.5),
        }
        for index in range(count)
    ]


def test_sampling_is_deterministic_and_marks_context() -> None:
    first = sample_source(
        SOURCE,
        _segments(),
        samples_per_source=2,
        target_words=120,
        context_words=30,
        seed=42,
    )
    second = sample_source(
        SOURCE,
        _segments(),
        samples_per_source=2,
        target_words=120,
        context_words=30,
        seed=42,
    )

    assert first == second
    assert len(first) == 2
    assert first[0].sample_end_segment < first[1].sample_start_segment
    first_indices = {
        segment.source_segment_index for segment in first[0].segments
    }
    second_indices = {
        segment.source_segment_index for segment in first[1].segments
    }
    assert first_indices.isdisjoint(second_indices)
    assert any(
        not segment.in_evaluation_region
        for segment in first[0].segments
    )
    assert all(
        segment.boundary_before == "" for segment in first[0].segments
    )


def test_template_and_flat_csv_keep_balanced_sources(
    tmp_path: Path,
) -> None:
    processed = tmp_path / "processed"
    processed.mkdir()
    segment_path = processed / "abcdefghijk.segments.jsonl"
    segment_path.write_text(
        "".join(json.dumps(row) + "\n" for row in _segments()),
        encoding="utf-8",
    )

    template = build_gold_template(
        [SOURCE],
        processed_dir=processed,
        samples_per_source=2,
        target_words=120,
        context_words=30,
        seed=42,
    )
    summary = write_outputs(
        template,
        manifest_hash="manifest-hash",
        output_dir=tmp_path / "annotations",
    )
    with (
        tmp_path
        / "annotations/segmentation_gold_v1.annotation_rows.csv"
    ).open(encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))

    assert summary["sample_count"] == 2
    assert summary["performance_count"] == 1
    assert {row["sample_id"] for row in rows} == {
        "abcdefghijk-seg-gold-v1-01",
        "abcdefghijk-seg-gold-v1-02",
    }
    assert all(row["boundary_before"] == "" for row in rows)
