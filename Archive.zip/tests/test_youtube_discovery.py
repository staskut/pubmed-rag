from __future__ import annotations

import csv
import json
from pathlib import Path

import pytest

from comedy_analyzer.discovery.youtube import (
    discover_candidates,
    iso8601_duration_seconds,
    load_config,
    load_env_value,
    write_csv,
    write_shortlist_csv,
)


class FakeYouTubeClient:
    def __init__(self) -> None:
        self.search_calls: list[dict] = []
        self.video_calls: list[list[str]] = []

    def search(self, params: dict) -> dict:
        self.search_calls.append(params)
        query = params["q"]
        video_id = "accepted001" if query.startswith("American") else "reject00002"
        return {
            "items": [
                {"id": {"videoId": video_id}},
                {"id": {"videoId": "accepted001"}},
            ]
        }

    def videos(self, video_ids: list[str]) -> dict:
        self.video_calls.append(video_ids)
        return {
            "items": [
                _video("accepted001"),
                _video(
                    "reject00002",
                    license_name="youtube",
                    captions="false",
                ),
            ]
        }


def _video(
    video_id: str,
    *,
    license_name: str = "creativeCommon",
    captions: str = "true",
) -> dict:
    return {
        "id": video_id,
        "snippet": {
            "title": f"Title {video_id}",
            "description": "Description",
            "channelTitle": "Creator channel",
            "channelId": "UC123",
            "publishedAt": "2024-01-01T00:00:00Z",
            "defaultAudioLanguage": "en",
        },
        "contentDetails": {
            "duration": "PT12M34S",
            "caption": captions,
            "licensedContent": False,
        },
        "status": {
            "license": license_name,
            "privacyStatus": "public",
            "embeddable": True,
        },
    }


def _config() -> dict:
    return {
        "schema_version": 1,
        "relevance_language": "en",
        "published_after": "2021-01-01T00:00:00Z",
        "published_before": None,
        "durations": ["medium"],
        "max_results_per_search": 50,
        "searches": [
            {
                "query": "American stand up comedy",
                "region_code": "US",
                "target_market": "US",
            },
            {
                "query": "British stand up comedy",
                "region_code": "GB",
                "target_market": "UK",
            },
        ],
    }


def test_duration_conversion() -> None:
    assert iso8601_duration_seconds("PT12M34S") == 754
    assert iso8601_duration_seconds("PT1H2M3S") == 3723
    assert iso8601_duration_seconds("P1DT1H") == 90_000
    assert iso8601_duration_seconds("not-a-duration") is None


def test_dotenv_key_is_read_without_shell_evaluation(tmp_path: Path) -> None:
    path = tmp_path / ".env"
    path.write_text(
        "# comment\nOTHER=value\nexport YOUTUBE_API_KEY='secret-value'\n",
        encoding="utf-8",
    )

    assert load_env_value(path, "YOUTUBE_API_KEY") == "secret-value"
    assert load_env_value(path, "MISSING") is None


def test_discovery_applies_filters_deduplicates_and_reverifies() -> None:
    client = FakeYouTubeClient()
    rows = discover_candidates(
        _config(),
        client,
        discovered_at="2026-07-25T00:00:00+00:00",
    )

    assert len(rows) == 2
    assert len(client.search_calls) == 2
    assert len(client.video_calls) == 1
    assert client.search_calls[0]["videoCaption"] == "closedCaption"
    assert client.search_calls[0]["videoLicense"] == "creativeCommon"

    accepted = next(row for row in rows if row["video_id"] == "accepted001")
    assert accepted["official_filter_passed"] is True
    assert accepted["duration_seconds"] == 754
    assert accepted["target_markets"] == "UK|US"
    assert accepted["language_metadata_passed"] is True
    assert accepted["subject_filter_passed"] is False

    rejected = next(row for row in rows if row["video_id"] == "reject00002")
    assert rejected["official_filter_passed"] is False
    assert rejected["filter_rejection_reasons"] == (
        "not_creative_common|captions_not_available"
    )


def test_csv_excludes_rejected_by_default(tmp_path: Path) -> None:
    rows = discover_candidates(
        _config(),
        FakeYouTubeClient(),
        discovered_at="2026-07-25T00:00:00+00:00",
    )
    output = tmp_path / "candidates.csv"

    count = write_csv(rows, output, include_rejected=False)
    with output.open(encoding="utf-8", newline="") as handle:
        written = list(csv.DictReader(handle))

    assert count == 1
    assert [row["video_id"] for row in written] == ["accepted001"]
    assert written[0]["manual_review_status"] == "pending"


def test_shortlist_keeps_likely_performance(tmp_path: Path) -> None:
    client = FakeYouTubeClient()
    original_videos = client.videos

    def videos_with_standup_title(video_ids: list[str]) -> dict:
        response = original_videos(video_ids)
        response["items"][0]["snippet"]["title"] = (
            "An Excellent Full Stand-Up Comedy Special"
        )
        return response

    client.videos = videos_with_standup_title  # type: ignore[method-assign]
    rows = discover_candidates(
        _config(),
        client,
        discovered_at="2026-07-25T00:00:00+00:00",
    )
    output = tmp_path / "shortlist.csv"

    count = write_shortlist_csv(rows, output)
    with output.open(encoding="utf-8", newline="") as handle:
        written = list(csv.DictReader(handle))

    assert count == 1
    assert written[0]["video_id"] == "accepted001"
    assert written[0]["subject_filter_passed"] == "True"
    assert "title_stand_up" in written[0]["subject_relevance_signals"]


def test_explicit_non_english_audio_is_not_shortlisted() -> None:
    client = FakeYouTubeClient()
    original_videos = client.videos

    def videos_with_hindi_standup(video_ids: list[str]) -> dict:
        response = original_videos(video_ids)
        response["items"][0]["snippet"]["title"] = "A Full Stand-Up Special"
        response["items"][0]["snippet"]["defaultAudioLanguage"] = "hi"
        return response

    client.videos = videos_with_hindi_standup  # type: ignore[method-assign]
    rows = discover_candidates(
        _config(),
        client,
        discovered_at="2026-07-25T00:00:00+00:00",
    )
    candidate = next(
        row for row in rows if row["video_id"] == "accepted001"
    )

    assert candidate["language_metadata_passed"] is False
    assert candidate["subject_filter_passed"] is False
    assert "audio_language_not_english" in candidate[
        "subject_relevance_signals"
    ]


def test_config_rejects_unsupported_duration(tmp_path: Path) -> None:
    config = _config()
    config["durations"] = ["short"]
    path = tmp_path / "config.json"
    path.write_text(json.dumps(config), encoding="utf-8")

    with pytest.raises(ValueError, match="durations"):
        load_config(path)
