from __future__ import annotations

import json
from pathlib import Path

import pytest

from comedy_analyzer.ingestion.youtube import (
    canonicalize,
    ingest_source,
    make_bit_candidates,
    read_manifest,
)


SOURCE = {
    "video_id": "abcdefghijk",
    "title": "Authorized test performance",
    "performer": "Test Comedian",
    "source_url": "https://www.youtube.com/watch?v=abcdefghijk",
    "spoken_language": "en",
    "rights_status": "permission_on_file",
    "license": "direct_permission",
    "approved_for_public_display": True,
}


class FakeAdapter:
    def fetch(self, video_id: str, languages: list[str]) -> dict:
        assert video_id == "abcdefghijk"
        assert languages[0] == "en"
        return {
            "language": "English",
            "language_code": "en",
            "is_generated": False,
            "is_translatable": True,
            "snippets": [
                {"text": "First &amp; clean line.", "start": 0.0, "duration": 2.0},
                {"text": "Second line here.", "start": 2.1, "duration": 2.0},
            ],
        }


def test_manifest_rejects_duplicate_video_ids(tmp_path: Path) -> None:
    path = tmp_path / "manifest.json"
    path.write_text(
        json.dumps({"schema_version": 1, "sources": [SOURCE, SOURCE]}),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="Duplicate video_id"):
        read_manifest(path)


def test_canonicalization_and_windows() -> None:
    raw = {
        "transcript": {
            "language_code": "en",
            "is_generated": False,
            "snippets": FakeAdapter().fetch("abcdefghijk", ["en"])["snippets"],
        }
    }
    segments = canonicalize(SOURCE, raw)
    bits = make_bit_candidates(segments, target_words=3, min_words=0)

    assert segments[0].text == "First & clean line."
    assert segments[0].end_seconds == 2.0
    assert len(bits) == 2
    assert bits[0].segmentation_method == "fixed_word_window_v0"


def test_tiny_punchline_fragment_is_merged_back_into_setup() -> None:
    raw = {
        "transcript": {
            "language_code": "en",
            "is_generated": False,
            "snippets": [
                {
                    "text": " ".join(["setup"] * 120),
                    "start": 0.0,
                    "duration": 40.0,
                },
                {
                    "text": "short punchline",
                    "start": 40.0,
                    "duration": 2.0,
                },
                {
                    "text": " ".join(["next"] * 120),
                    "start": 51.0,
                    "duration": 40.0,
                },
            ],
        }
    }
    bits = make_bit_candidates(canonicalize(SOURCE, raw))

    assert len(bits) == 2
    assert bits[0].word_count == 122
    assert bits[0].text.endswith("short punchline")


def test_ingestion_writes_cache_processed_records_and_qa(
    tmp_path: Path,
) -> None:
    report = ingest_source(
        SOURCE,
        data_dir=tmp_path,
        adapter=FakeAdapter(),
        allow_test_only=False,
        refresh=False,
    )

    assert report["cache_status"] == "miss"
    assert report["checks"]["timestamps_monotonic"] is True
    assert report["consecutive_duplicate_segment_texts"] == 0
    assert (tmp_path / "raw/youtube/abcdefghijk.json").exists()
    assert (
        tmp_path / "processed/youtube/abcdefghijk.segments.jsonl"
    ).exists()
    assert (
        tmp_path / "processed/youtube/abcdefghijk.bit-candidates.jsonl"
    ).exists()
    assert (tmp_path / "processed/youtube/abcdefghijk.qa.json").exists()

    cached_report = ingest_source(
        SOURCE,
        data_dir=tmp_path,
        adapter=FakeAdapter(),
        allow_test_only=False,
        refresh=False,
    )
    assert cached_report["cache_status"] == "hit"
